# Medical Insurance Cost Prediction Pipeline

This project implements a complete machine learning pipeline for predicting medical insurance costs, including ETL (Extract, Transform, Load) processes, model training, evaluation, and deployment.

## Project Structure

```
medical-insurance-prediction/
├── data/
│   ├── raw/                  # Raw data files
│   └── processed/            # Processed data files
├── logs/                     # Log files
├── model/                    # Trained model files
├── results/                  # Pipeline execution results
├── etl.py                    # ETL pipeline implementation
├── model.py                  # ML model training and evaluation
├── run.py                    # Main pipeline orchestrator
├── schedules.py              # Logging test script
└── README.md                 # This file
```

## Features

1. **ETL Pipeline**:
   - Data extraction from Kaggle
   - Data cleaning and transformation
   - Feature engineering
   - Database loading

2. **Machine Learning Pipeline**:
   - Multiple model training (Linear Regression, Random Forest)
   - Model evaluation with cross-validation
   - Model persistence (pickle and joblib formats)

3. **Logging & Monitoring**:
   - Comprehensive logging setup
   - Daily and per-run log files
   - Pipeline execution tracking

4. **Results Management**:
   - JSON results storage
   - Status reporting
   - Duration tracking

## Prerequisites

- Python 3.8+
- Required packages (install via `pip install -r requirements.txt`):
  ```
  pandas
  numpy
  scikit-learn
  sqlalchemy
  python-dotenv
  kagglehub
  ```

## Configuration

1. Create a `.env` file with database credentials:
   ```
   DB_USERNAME=your_username
   DB_PASSWORD=your_password
   DB_HOST=your_host
   DB_PORT=3306
   DB_DATABASE=your_database
   ```

2. Ensure proper directory structure exists (will be created automatically if missing):
   - `data/raw/`
   - `data/processed/`
   - `logs/`
   - `model/`
   - `results/`

## Usage

1. **Run complete pipeline**:
   ```bash
   python run.py
   ```

2. **Run ETL only**:
   ```bash
   python etl.py
   ```

3. **Run model training only**:
   ```bash
   python model.py
   ```

4. **For enabling scheduling**:
   ```bash
   python schedules.py
   ```

## Output

- Trained models in `model/` directory
- Log files in `logs/` directory
- JSON results in `results/` directory
- Console output with execution summary

## Example Output

```
============================================================
PIPELINE EXECUTION SUMMARY
============================================================
Overall Status: SUCCESS
Duration: 0:00:03.784724
✅ Pipeline completed successfully!
✅ Best model trained: random_forest
============================================================
```
